import requests
import base64
import json

def get_patients_referred_by(patient_id, api_key):
    """
    Get all patients referred by a specific patient using new Cliniko filter
    """
    url = "https://api.cliniko.com/v1/referral_sources"
    headers = {
        'Authorization': f'Basic {base64.b64encode(f"{api_key}:".encode()).decode()}',
        'Accept': 'application/json'
    }
    params = {
        'referrer_id': patient_id,  # NEW FILTER CAPABILITY!
        'per_page': 50
    }
    
    all_referrals = []
    
    while url:
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            data = response.json()
            all_referrals.extend(data.get('referral_sources', []))
            url = data.get('links', {}).get('next')
            params = None  # Clear params for subsequent requests
        else:
            print(f"Error: {response.status_code} - {response.text}")
            break
    
    return all_referrals

def calculate_referrer_score(patient_id, api_key):
    """
    Calculate referrer score based on number of patients referred
    """
    referrals = get_patients_referred_by(patient_id, api_key)
    referral_count = len(referrals)
    
    # Scoring logic (example)
    if referral_count >= 5:
        return 100  # Excellent referrer
    elif referral_count >= 3:
        return 75   # Good referrer
    elif referral_count >= 1:
        return 50   # Some referrals
    else:
        return 0    # No referrals

# TEST THE FUNCTIONS
if __name__ == "__main__":
    # Your Cliniko API key
    API_KEY = "MS0xNzIwNjExOTk1MjMwNjY3Nzk4LWJieWZXTDBvV2w5L1pYOFVsK3hsRlFPeHlocmhkbVRw-au1"
    
    # Test with a patient ID (replace with actual patient ID)
    TEST_PATIENT_ID = "12345"  # Replace with real patient ID
    
    print("🔍 TESTING REFERRER SCORE FUNCTIONALITY")
    print("=" * 38)
    
    print(f"📋 Testing patient ID: {TEST_PATIENT_ID}")
    
    # Test getting referrals
    print(f"\n🎯 STEP 1: Get patients referred by patient {TEST_PATIENT_ID}")
    referrals = get_patients_referred_by(TEST_PATIENT_ID, API_KEY)
    
    print(f"✅ Found {len(referrals)} referrals")
    
    if referrals:
        print(f"\n📋 REFERRAL DETAILS:")
        for i, referral in enumerate(referrals[:5]):  # Show first 5
            print(f"   {i+1}. Patient ID: {referral.get('patient_id')}")
            print(f"      Referral ID: {referral.get('id')}")
            print(f"      Notes: {referral.get('notes', 'No notes')}")
    
    # Test calculating score
    print(f"\n🎯 STEP 2: Calculate referrer score")
    score = calculate_referrer_score(TEST_PATIENT_ID, API_KEY)
    print(f"✅ Referrer Score: {score}/100")
    
    print(f"\n🎉 TEST COMPLETED!")
