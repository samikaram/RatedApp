import re

# Read the HTML file
with open("./templates/patient_rating/unified_dashboard.html", "r") as f:
    content = f.read()

# Debugging JavaScript to inject
debug_js = '''
function toggleSettingsPanel() {
    console.log('🔧 Toggle Settings Panel called');
    console.log('🔧 Settings Button:', settingsButton);
    console.log('🔧 Settings Panel:', settingsPanel);
    
    if (!settingsPanel) {
        console.error('❌ Settings panel not found!');
        return;
    }
    
    console.log('🔧 Current classList:', settingsPanel.classList);
    settingsPanel.classList.toggle('open');
    console.log('🔧 After toggle classList:', settingsPanel.classList);
    
    if (settingsPanel.classList.contains('open')) {
        console.log('🔧 Panel should be visible now');
        fetchCurrentSettings();
    } else {
        console.log('🔧 Panel should be hidden now');
    }
}'''

# Replace the existing function
modified_content = re.sub(
    r'function toggleSettingsPanel$$ {[^}]+}',
    debug_js,
    content,
    flags=re.DOTALL
)

# Write back to file
with open("./templates/patient_rating/unified_dashboard.html", "w") as f:
    f.write(modified_content)

print('✅ Added JavaScript debugging')
print('Now refresh the page and check browser console when clicking Settings')
