import re

with open("./templates/patient_rating/unified_dashboard.html", "r") as f:
    content = f.read()

modified_content = re.sub(
    r"<button id='settings-button'[^>]*>Settings</button>", 
    "<span id='settings-button' style='margin-left: 10px; color: inherit; cursor: pointer; font-size: 0.9rem;'>Settings</span>", 
    content
)

head_close = modified_content.find("</head>")

css_styles = """
<style>
    #settings-button {
        transition: color 0.3s ease, opacity 0.3s ease;
        display: inline-block;
    }

    #settings-button:hover {
        color: #666;
        opacity: 0.7;
    }
</style>
"""

final_content = modified_content[:head_close] + css_styles + modified_content[head_close:]

with open("./templates/patient_rating/unified_dashboard.html", "w") as f:
    f.write(final_content)

print("✅ Settings Text Styling Updated")
print("\nVerification:")
print("Button replaced with span" if "settings-button" in final_content else "❌ Replacement Failed")
