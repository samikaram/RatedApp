import re

def add_class_to_element(content, element_type, id_value, class_name):
    # More flexible pattern to match the element
    pattern = rf'({element_type}\s+id=[\'"]?{id_value}[\'"]?[^>]*)'
    
    # Check if class already exists
    if re.search(rf'class=[\'"].*{class_name}.*[\'"]', content):
        return content
    
    # Replace pattern, adding the class
    modified_content = re.sub(
        pattern, 
        rf'\1 class="{class_name}"', 
        content
    )
    
    return modified_content

# Read the HTML file
with open("./templates/patient_rating/unified_dashboard.html", "r") as f:
    content = f.read()

# Define elements to modify
elements = [
    {"type": "span", "id": "settings-button", "class": "settings-button"},
    {"type": "div", "id": "settings-hover-panel", "class": "settings-hover-panel"},
    {"type": "button", "id": "close-settings-panel", "class": "close-settings-panel"},
    {"type": "button", "id": "edit-clinic-settings", "class": "edit-clinic-settings"},
    {"type": "button", "id": "save-clinic-settings", "class": "save-clinic-settings"}
]

# Apply modifications
modified_content = content
for element in elements:
    modified_content = add_class_to_element(
        modified_content, 
        element['type'], 
        element['id'], 
        element['class']
    )

# Write back to file
with open("./templates/patient_rating/unified_dashboard.html", "w") as f:
    f.write(modified_content)

print("✅ Added missing classes")

# Verification
for element in elements:
    if f'id="{element["id"]}"' in modified_content:
        print(f"✅ {element['id']} ID found")
        # Additional check for class
        if f'class="{element["class"]}"' in modified_content:
            print(f"✅ {element['class']} class added")
        else:
            print(f"❌ {element['class']} class missing")
    else:
        print(f"❌ {element['id']} ID missing")
