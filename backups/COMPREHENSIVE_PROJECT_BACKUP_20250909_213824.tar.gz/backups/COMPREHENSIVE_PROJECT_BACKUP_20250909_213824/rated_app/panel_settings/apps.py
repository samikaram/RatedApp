from django.apps import AppConfig


class PanelSettingsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'panel_settings'
