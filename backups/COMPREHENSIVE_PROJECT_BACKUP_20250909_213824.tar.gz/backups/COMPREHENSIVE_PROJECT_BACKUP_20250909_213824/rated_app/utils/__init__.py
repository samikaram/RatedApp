# Patient rating utilities
