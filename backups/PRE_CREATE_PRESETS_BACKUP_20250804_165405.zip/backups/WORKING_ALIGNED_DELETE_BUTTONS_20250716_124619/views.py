import json
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.views import View
from django.contrib import messages
import requests
import base64
from .models import ScoringConfiguration, Patient
from .utils.patient_analyzer import analyze_patient_behavior

# Cliniko API Configuration
RAW_API_KEY = "MS0xNzIwNjExOTk1MjMwNjY3Nzk4LWJieWZXTDBvV2w5L1pYOFVsK3hsRlFPeHlocmhkbVRw-au1"
ENCODED_API_KEY = base64.b64encode(f"{RAW_API_KEY}:".encode()).decode()
BASE_URL = "https://api.au1.cliniko.com/v1"
HEADERS = {
    'Authorization': f'Basic {ENCODED_API_KEY}',
    'Accept': 'application/json',
    'User-Agent': 'RatedApp Patient Search'
}

class HomeView(View):
    def get(self, request):
        return render(request, 'patient_rating/home.html')

class PatientSearchView(View):
    def get(self, request):
        return render(request, 'patient_rating/patient_search.html')
    
    def post(self, request):
        search_type = request.POST.get('search_type', 'name')
        search_value = request.POST.get('search_value', '').strip()
        
        if not search_value:
            return render(request, 'patient_rating/patient_search.html', {
                'error': 'Please enter a search value'
            })
        
        try:
            if search_type == 'name':
                patients = self.search_by_name(search_value)
            elif search_type == 'id':
                patients = self.search_by_id(search_value)
            else:
                patients = []
            
            return render(request, 'patient_rating/patient_search.html', {
                'patients': patients,
                'search_value': search_value,
                'search_type': search_type
            })
        except Exception as e:
            return render(request, 'patient_rating/patient_search.html', {
                'error': f'Search failed: {str(e)}'
            })
    
    def get_phone_numbers(self, patient):
        phone_numbers = patient.get('patient_phone_numbers', [])
        if not phone_numbers:
            return "Not provided"
        formatted_phones = []
        for phone in phone_numbers:
            number = phone.get('number', '')
            phone_type = phone.get('phone_type', '')
            if number:
                formatted_phones.append(f"{number} ({phone_type})")
        return " | ".join(formatted_phones) if formatted_phones else "Not provided"
    
    def search_by_name(self, name):
        name_parts = name.split(' ', 1)
        first_name = name_parts[0]
        url = f"{BASE_URL}/patients"
        params = {'q[]': f'first_name:={first_name}'}
        response = requests.get(url, headers=HEADERS, params=params)
        response.raise_for_status()
        data = response.json()
        patients = data.get('patients', [])
        formatted_patients = []
        for patient in patients:
            phone = self.get_phone_numbers(patient)
            formatted_patients.append({
                'id': patient.get('id'),
                'first_name': patient.get('first_name'),
                'last_name': patient.get('last_name'),
                'email': patient.get('email'),
                'phone': phone,
                'date_of_birth': patient.get('date_of_birth'),
                'full_name': f"{patient.get('first_name', '')} {patient.get('last_name', '')}".strip()
            })
        return formatted_patients
    
    def search_by_id(self, patient_id):
        url = f"{BASE_URL}/patients/{patient_id}"
        response = requests.get(url, headers=HEADERS)
        response.raise_for_status()
        patient = response.json()
        phone = self.get_phone_numbers(patient)
        return [{
            'id': patient.get('id'),
            'first_name': patient.get('first_name'),
            'last_name': patient.get('last_name'),
            'email': patient.get('email'),
            'phone': phone,
            'date_of_birth': patient.get('date_of_birth'),
            'full_name': f"{patient.get('first_name', '')} {patient.get('last_name', '')}".strip()
        }]

class ScoringConfigurationView(View):
    def get(self, request):
        active_config = ScoringConfiguration.get_active_config()
        all_configs = ScoringConfiguration.objects.all()
        age_brackets = active_config.age_brackets.all().order_by('min_age')
        
        return render(request, 'patient_rating/scoring_config.html', {
            'active_config': active_config,
            'all_configs': all_configs,
            'age_brackets': age_brackets
        })
    
    def post(self, request):
        action = request.POST.get('action')
        
        if action == 'update_weights':
            config = ScoringConfiguration.get_active_config()
            
            # Update all weights from sliders
            config.future_appointments_weight = int(request.POST.get('future_appointments_weight', 20))
            config.age_demographics_weight = int(request.POST.get('age_demographics_weight', 10))
            config.yearly_spend_weight = int(request.POST.get('yearly_spend_weight', 25))
            config.consecutive_attendance_weight = int(request.POST.get('consecutive_attendance_weight', 30))
            config.points_per_consecutive_attendance = int(request.POST.get('points_per_consecutive_attendance', 2))
            config.likability_weight = int(request.POST.get('likability_weight', 20))
            config.cancellations_weight = int(request.POST.get('cancellations_weight', 20))
            config.points_per_cancellation = int(request.POST.get('points_per_cancellation', 3))
            config.points_per_unpaid_invoice = int(request.POST.get('points_per_unpaid_invoice', 10))
            config.dna_weight = int(request.POST.get('dna_weight', 50))
            config.points_per_dna = int(request.POST.get('points_per_dna', 5))
            config.unpaid_invoices_weight = int(request.POST.get('unpaid_invoices_weight', 50))
            config.open_dna_invoice_weight = int(request.POST.get('open_dna_invoice_weight', 100))
            config.unlikability_weight = int(request.POST.get('unlikability_weight', 20))
            config.save()
            messages.success(request, 'Scoring weights updated successfully!')
            
        elif action == 'save_preset':
            name = request.POST.get('preset_name', 'New Configuration')
            description = request.POST.get('preset_description', '')
            
            # Create new configuration with current weights
            active_config = ScoringConfiguration.get_active_config()
            new_config = ScoringConfiguration.objects.create(
                name=name,
                description=description,
                future_appointments_weight=active_config.future_appointments_weight,
                age_demographics_weight=active_config.age_demographics_weight,
                yearly_spend_weight=active_config.yearly_spend_weight,
                consecutive_attendance_weight=active_config.consecutive_attendance_weight,
                likability_weight=active_config.likability_weight,
                cancellations_weight=active_config.cancellations_weight,
                dna_weight=active_config.dna_weight,
                unpaid_invoices_weight=active_config.unpaid_invoices_weight,
                open_dna_invoice_weight=active_config.open_dna_invoice_weight,
                unlikability_weight=active_config.unlikability_weight,
                is_active=False
            )
            messages.success(request, f'Preset "{name}" saved successfully!')
            
        elif action == 'load_preset':
            config_id = request.POST.get('config_id')
            if config_id:
                config = get_object_or_404(ScoringConfiguration, id=config_id)
                config.is_active = True
                config.save()
                messages.success(request, f'Loaded preset "{config.name}"')
        
        elif action == 'add_age_bracket':
            config = ScoringConfiguration.get_active_config()
            min_age = int(request.POST.get('min_age', 0))
            max_age = int(request.POST.get('max_age', 100))
            percentage = int(request.POST.get('percentage', 50))
            
            # Validate no overlapping brackets
            existing_brackets = config.age_brackets.all()
            for bracket in existing_brackets:
                if not (max_age < bracket.min_age or min_age > bracket.max_age):
                    messages.error(request, f'Age bracket {min_age}-{max_age} overlaps with existing bracket {bracket.min_age}-{bracket.max_age}')
                    return redirect('scoring_config')
            
            # Create new bracket
            from .models import AgeBracket
            new_order = existing_brackets.count() + 1
            AgeBracket.objects.create(
                config=config,
                min_age=min_age,
                max_age=max_age,
                percentage=percentage,
                order=new_order
            )
            messages.success(request, f'Added age bracket {min_age}-{max_age} ({percentage}%)')
            
        elif action == 'edit_age_bracket':
            bracket_id = request.POST.get('bracket_id')
            if bracket_id:
                from .models import AgeBracket
                bracket = get_object_or_404(AgeBracket, id=bracket_id)
                bracket.min_age = int(request.POST.get('min_age', bracket.min_age))
                bracket.max_age = int(request.POST.get('max_age', bracket.max_age))
                bracket.percentage = int(request.POST.get('percentage', bracket.percentage))
                bracket.save()
                messages.success(request, f'Updated age bracket {bracket.min_age}-{bracket.max_age} ({bracket.percentage}%)')
            
        elif action == 'delete_age_bracket':
            bracket_id = request.POST.get('bracket_id')
            if bracket_id:
                from .models import AgeBracket
                bracket = get_object_or_404(AgeBracket, id=bracket_id)
                bracket_description = f'{bracket.min_age}-{bracket.max_age} ({bracket.percentage}%)'
                bracket.delete()
                messages.success(request, f'Deleted age bracket {bracket_description}')
        
        return redirect('scoring_config')

class PatientAnalysisView(View):
    def get(self, request, patient_id):
        return render(request, 'patient_rating/patient_analysis.html', {
            'patient_id': patient_id
        })
    
    def post(self, request, patient_id):
        try:
            # Get active scoring configuration for dynamic weights
            config = ScoringConfiguration.get_active_config()
            analysis = analyze_patient_behavior(patient_id, config)
            
            if analysis:
                return JsonResponse({
                    'status': 'success',
                    'analysis': analysis
                })
            else:
                return JsonResponse({
                    'status': 'error',
                    'message': 'Analysis failed'
                })
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            })

class UpdateLikabilityView(View):
    def post(self, request):
        try:
            data = json.loads(request.body)
            patient_id = data.get('patient_id')
            likability_value = int(data.get('likability', 0))
            
            # Get or create patient record
            patient, created = Patient.objects.get_or_create(
                cliniko_patient_id=patient_id,
                defaults={'patient_name': f'Patient {patient_id}'}
            )
            
            # Update likability value
            patient.likability = likability_value
            patient.save()
            
            return JsonResponse({'success': True})
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

class UpdateUnlikabilityView(View):
    def post(self, request):
        try:
            data = json.loads(request.body)
            patient_id = data.get('patient_id')
            unlikability_value = int(data.get('unlikability', 0))
            
            # Get or create patient record
            patient, created = Patient.objects.get_or_create(
                cliniko_patient_id=patient_id,
                defaults={'patient_name': f'Patient {patient_id}'}
            )
            
            # Update unlikability value
            patient.unlikability = unlikability_value
            patient.save()
            
            return JsonResponse({'success': True})
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

def unified_dashboard(request):
    from .models import AgeBracket, ScoringConfiguration
    if request.method == "POST":
        try:
            active_config = ScoringConfiguration.objects.get(is_active=True)
            
            # Handle age bracket deletion
            action = request.POST.get('action')
            if action == 'delete_age_bracket':
                bracket_id = request.POST.get('bracket_id')
                if bracket_id:
                    from django.shortcuts import get_object_or_404
                    from .models import AgeBracket
                    bracket = get_object_or_404(AgeBracket, id=bracket_id)
                    bracket.delete()
                    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                        return JsonResponse({"success": True})
            
            active_config.future_appointments_weight = int(request.POST.get("future_appointments_weight", active_config.future_appointments_weight))
            active_config.age_demographics_weight = int(request.POST.get("age_demographics_weight", active_config.age_demographics_weight))
            active_config.save()
            # Handle AJAX requests
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return JsonResponse({"success": True})
            from django.http import HttpResponseRedirect
            from django.urls import reverse
            return HttpResponseRedirect(reverse("unified_dashboard") + "?saved=true")
        except (ValueError, TypeError, ScoringConfiguration.DoesNotExist):
            pass
    
    # GET request - display the dashboard
    try:
        active_config = ScoringConfiguration.objects.get(is_active=True)
        age_brackets = AgeBracket.objects.filter(config=active_config).order_by('order')
    except ScoringConfiguration.DoesNotExist:
        active_config = None
        age_brackets = []
    
    context = {
        'active_config': active_config,
        'age_brackets': age_brackets,
    }
    
    return render(request, 'patient_rating/unified_dashboard.html', context)
